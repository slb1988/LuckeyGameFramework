﻿using UnityEngine;
using System.Collections;

public class EntityTest : MonoBehaviour {
    Entity entity;

	// Use this for initialization
	void Start () {

        entity = gameObject.AddComponent<Entity>();


	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
