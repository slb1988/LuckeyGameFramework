﻿using UnityEngine;
using System.Collections;
using System;

public class EventTest1 : MonoBehaviour {

    EventController eventController = new EventController();
    Delegate del;
    

	// Use this for initialization
	void Start () {
        eventController.AddEventListener("fire", OnFire);
        eventController.TriggerEvent("fire");

        //Func<string>(OnTest);
        Func2<string, string>(OnTest2);

        del.DynamicInvoke("hahahh", "kjkjkjk");
	}

    void Func<T>(Action<T> act)
    {
        del = act;
    }

    void Func2<T, U>(Action<T, U> act)
    {
        del = act;
    }

    void OnTest(string str)
    {
        Debug.Log("asdfasf  " + str);
    }
    void OnTest2(string str, string str2)
    {
        Debug.Log("asdfasf  " + str + str2);
    }

    void OnFire()
    {
        Debug.Log("OnFire" + Time.time);
    }
	
	// Update is called once per frame
	void Update () {
	
	}
}
