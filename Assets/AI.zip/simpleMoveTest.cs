﻿using UnityEngine;
using System.Collections;

public class simpleMoveTest : MonoBehaviour {
    float speed = 3.0f;
    float rotateSpeed = 3.0f;

    CharacterController controller;

	// Use this for initialization
	void Start () {
	
		controller = GetComponent<CharacterController>();
	}
	
	// Update is called once per frame
	void Update () {

        // Rotate around y - axis
        transform.Rotate(0, Input.GetAxis("Horizontal") * rotateSpeed, 0);

        // Move forward / backward
        Vector3 forward = transform.TransformDirection(Vector3.forward);
        float curSpeed = speed * Input.GetAxis("Vertical");
        controller.SimpleMove(forward * curSpeed);
	}
}
