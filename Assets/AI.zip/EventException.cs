﻿using System;

/// <summary>
/// 事件异常
/// </summary>
[Serializable]
public class EventException : Exception
{
    public EventException(string message) : base(message) { }
}

