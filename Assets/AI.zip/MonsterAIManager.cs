﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class MonsterAIManager : MonoBehaviour
{
    public MonsterReceiver receiver;
    public List<uint> enemyList = new List<uint>();

    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }

    public void BeAttacked(uint src, int attackvalue, int buffid)
    {

    }

}
