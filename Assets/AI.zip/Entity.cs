﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public enum eEntityComponent
{
    locomotor,
}

public interface IEntityComponent
{

}

public class Entity : MonoBehaviour
{
    long GUID;

    float spawntime;
    bool persists;
    bool inlimbo;
    string name;
    Object data;
    EventController listers;

    public SoundManager SoundEmitter;
    public Animation AnimState;
    public Physics Physics;

    public StateGraphInstance sg;
    public Dictionary<eEntityComponent, Component> components = new Dictionary<eEntityComponent, Component>(); 

    static long currentGUID = 0;
    static long GetGUID()
    {
        return ++currentGUID;
    }

    void Start()
    {
        GUID = GetGUID();
        spawntime = Time.realtimeSinceStartup;

        SGflog tempSg = new SGflog();
        // 读取配置表确定行为

        sg = new StateGraphInstance(tempSg, this);

        AIManager.Ents.Add(GUID, this);
    }

    void OnDestroy()
    {
        AIManager.Ents.Remove(GUID);
    }

    void Update()
    {

    }
}
