﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

public class ACTIONS
{
    public static StateAction REPAIR = new StateAction();
    public static StateAction READ = new StateAction();
    public static StateAction DROP = new StateAction();
    public static StateAction TRAVEL = new StateAction();
    public static StateAction CHOP = new StateAction();
    public static StateAction ATTACK = new StateAction();
    public static StateAction FORCEATTACK = new StateAction();
    public static StateAction EAT = new StateAction();
    public static StateAction PICK = new StateAction();
    public static StateAction PICKUP = new StateAction();
    public static StateAction MINE = new StateAction();
    public static StateAction DIG = new StateAction();
    public static StateAction GIVE = new StateAction();
    public static StateAction COOK = new StateAction();
    public static StateAction DRY = new StateAction();
    public static StateAction ADDFUEL = new StateAction();
    public static StateAction LIGHT = new StateAction(-4);
    public static StateAction EXTINGUISH = new StateAction(0);
    public static StateAction LOOKAT = new StateAction(-3, true);
    public static StateAction TALKTO = new StateAction(3, true);
    public static StateAction WALKTO = new StateAction(-4);
    public static StateAction BAIT = new StateAction();
    public static StateAction CHECKTRAP = new StateAction(2);
    public static StateAction BUILD = new StateAction();
    public static StateAction PLANT = new StateAction();
    public static StateAction HARVEST = new StateAction();
    public static StateAction GOHOME = new StateAction();
    public static StateAction SLEEPIN = new StateAction(0, true);
    public static StateAction EQUIP = new StateAction(-2, true);
    public static StateAction UNEQUIP = new StateAction();
    //--OPEN_SHOP = Action(),
    //public static StateAction REPAIR = new StateAction();
    //public static StateAction REPAIR = new StateAction();
    //public static StateAction REPAIR = new StateAction();

    //SHAVE = Action(),
    //STORE = Action(),
    //RUMMAGE = Action(-1),
    //DEPLOY = Action(),
    //PLAY = Action(),
    //NET = Action(3),
    //CATCH = Action(3, true),
    //FISH = Action(),
    //REEL = Action(0, true),
    //POLLINATE = Action(),
    //FERTILIZE = Action(),
    //LAYEGG = Action(),
    //HAMMER = Action(3),
    //TERRAFORM = Action(),
    //JUMPIN = Action(),
    //RESETMINE = Action(3),
    //ACTIVATE = Action(),
    //MURDER = Action(0),
    //HEAL = Action(),
    //INVESTIGATE = Action(),
    //UNLOCK = Action(),
    //TEACH = Action(),
    //TURNON = Action(2),
    //TURNOFF = Action(2),
    //SEW = Action(),
    //STEAL = Action(),
    //USEITEM = Action(1, true),
    //TAKEITEM = Action(),
    //MAKEBALLOON = Action(),
    //CASTSPELL = Action(0, false, true, 20),
    //BLINK = Action(10, false, true, 36),
    //COMBINESTACK = Action(),
    //TOGGLE_DEPLOY_MODE = Action(1),
}

public class StateAction
{
    public int id;
    public int priority;
    public Func<Entity, int, bool> fn;
    public Func<string, bool> strfn;
    //success reason
    public Func<bool, string> testfn;
    public bool instant;
    public object rmb;
    public int distance;

    public StateAction()
    {
        //fn = new Func<int, bool>((b)=>{ return FuncTest(b);});
    }

    bool FuncTest(int i)
    {
        return false;
    }

    public StateAction(int priority, bool instant = false, int rmb = 0, int distance = 0)
    {
        this.priority = priority;

    }
}

