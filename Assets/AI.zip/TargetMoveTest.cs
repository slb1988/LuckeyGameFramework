﻿using UnityEngine;
using System.Collections;
//using Pathfinding;

public class TargetMoveTest : MonoBehaviour {

    public LayerMask mask;
    //Seeker seeker;
    Camera cam;

    public Vector3 targetPosition;
    public Transform target;

    //public Path path;
    public float speed = 100;
    public float nextWaypointDistance = 3;

    //private int currentWaypoint = 0;

    //private CharacterController controller;
	// Use this for initialization
    void Awake()
    {
        //controller = GetComponent<CharacterController>();

        //seeker = gameObject.GetComponent<Seeker>();
        cam = Camera.main;
	}
	
	// Update is called once per frame
	void Update () {
        if (Input.GetMouseButtonDown(0))
        {
            RaycastHit hit;
            if (Physics.Raycast(cam.ScreenPointToRay(Input.mousePosition), out hit, Mathf.Infinity, mask)
                && hit.point != target.position)
            {
                targetPosition = hit.point;
                target.position = targetPosition;
                //seeker.StartPath(transform.position, targetPosition, OnPathComplete);
            }
        }
	}

    public float factor = 0.3f;
    Vector3 dir;
    /*
    float heiht = 41.18975f;
    public void FixedUpdate()
    {
        if (path == null)
        {
            return;
        }
        if (currentWaypoint >= path.vectorPath.Count)
        {
            //  Debug.Log(currentWaypoint + "End of Path Reached." + path.vectorPath.Count);
            return;
        }
        dir = (path.vectorPath[currentWaypoint] - transform.position).normalized;
        dir *= speed * Time.fixedDeltaTime;
//         print(transform.position);
//         print(target.position);
//         print(dir);

        //controller.SimpleMove(dir);
        Vector3 v = transform.position;
        v = transform.position + dir * factor;
        v.y = heiht;
        transform.position = v;

        if (Vector3.Distance(transform.position, path.vectorPath[currentWaypoint]) < nextWaypointDistance)
        {
            currentWaypoint++;
            return;
        }
    }

    void OnPathComplete(Path p)
    {
        Debug.Log("Yay, we got a path back. Did it have an error? " + p.error);
        if (!p.error)
        {
            path = p;
            currentWaypoint = 0;
        }
    }
     */
}
