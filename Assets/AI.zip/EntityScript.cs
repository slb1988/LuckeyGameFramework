﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class EntityScript : MonoBehaviour
{
    //List<string> StateGraphs = new List<string>();
    //List<Component> Components = new List<Component>();

    long GUID;
    //Entity entity;

    float spawntime;
    bool persists;
    bool inlimbo;
    string name;
    Object data;
    EventController listers;

    static long currentGUID = 0;
    static long GetGUID()
    {
        return ++currentGUID;
    }

    void Start()
    {
        //this.entity = this;
        GUID = GetGUID();
        spawntime = Time.realtimeSinceStartup;

        //AIManager.Ents.Add(GUID, this);
    }

    void OnDestroy()
    {
        //AIManager.Ents.Remove(GUID);
    }

    void Update()
    {

    }
}
