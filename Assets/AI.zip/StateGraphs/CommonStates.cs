﻿using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;

// 公用事件捕获器

public class CommonHandlers
{
    public static void OnStep(EventController events)
    {
        events.AddEventListener("step",
                                (Entity entity) =>
                                {
                                    Debug.Log("OnStep");
                                });
    }

    public static void OnSleep(EventController events)
    {
        events.AddEventListener("gotosleep",
                            (Entity inst) =>
                            {
                                Debug.Log("OnSleep");
                            });
    }

    public static void OnFreeze(EventController events)
    {
        events.AddEventListener("freeze",
                            (Entity inst) =>
                            {
                                Debug.Log("frozen");
                            });
    }

    public static void OnAttacked(EventController events)
    {
        events.AddEventListener("attacked",
                            (Entity inst) =>
                            {
                                Debug.Log("attacked");
                            });
    }

    public static void OnAttack(EventController events)
    {
        events.AddEventListener("doattack",
                            (Entity inst) =>
                            {
                                Debug.Log("doattack");
                            });
    }

    public static void OnDeath(EventController events)
    {
        events.AddEventListener("death",
                            (Entity inst) =>
                            {
                                Debug.Log("death" + Time.time);
                            });
    }

    public static void OnLocomote(EventController events, bool can_move, bool can_run)
    {
        events.AddEventListener("locomote",
                            (Entity inst) =>
                            {
                                Debug.Log("locomote" + can_move +" " + can_run);
                            });
    }
}

public static class CommonStates
{
    public static void AddIdle(Dictionary<string, State> states,
                                string funny_idle_state,
                                Func<string> anim_override,
                                List<ITimeEvent> timeline)
    {

        State idle = new State("idle",
                            "idle", "canrotate");

        states.Add(idle.name, idle);
    }

    public static void AddSleepStates(Dictionary<string, State> states,
                                Dictionary<string, List<ITimeEvent>> timelines,
                                Dictionary<string, Action<Entity>> fns)
    {
        State startsleep = new State("sleep",
                                    "busy", "sleeping");
        startsleep.onenter = new Action<Entity>((Entity inst) =>
                            {
                                //inst.components["locomotor"];
                                Debug.Log("sleep onenter.");
                                if (fns != null && fns.ContainsKey("onsleep"))
                                    fns["onsleep"].Invoke(inst);
                            });
        startsleep.events.AddEventListener("animover",
                                    (Entity inst) =>
                                    {
                                        inst.sg.GoToState("sleeping");
                                    });
        startsleep.events.AddEventListener("onwakeup",
                                    (Entity inst) =>
                                    {
                                        inst.sg.GoToState("wake");
                                    });

        State sleep = new State("sleeping",
                                "busy", "sleeping");
        sleep.onenter = new Action<Entity>((Entity inst) =>
            {
                inst.AnimState.CrossFade("sleep_loop");
            });
        sleep.events.AddEventListener("animover", (Entity inst) =>
                                    {
                                        inst.sg.GoToState("sleeping");
                                    });
        sleep.events.AddEventListener("onwakeup", (Entity inst) =>
                                    {
                                        inst.sg.GoToState("wake");
                                    });

        State endsleep = new State("wake",
                                "busy", "waking");
        endsleep.onenter = new Action<Entity>((Entity inst) =>
                        {
                            //inst.components[];
                            Debug.Log("wake onenter");
                            if (fns != null && fns.ContainsKey("onwake"))
                                fns["onwake"].Invoke(inst);
                        });
        endsleep.events.AddEventListener("animover", (Entity inst) =>
                                {
                                    inst.sg.GoToState("idle");
                                });

        State forcesleep = new State("forcesleep",
                                "busy", "sleeping");
        forcesleep.onenter = new Action<Entity>((Entity inst) =>
                            {
                                //inst.components["locomotor"]
                                Debug.Log("forcesleep onenter");
                            });

        if (timelines != null)
        {
            startsleep.timeline = timelines["starttimeline"];
            sleep.timeline = timelines["sleeptimeline"];
            endsleep.timeline = timelines["waketimeline"];
        }
        states.Add(startsleep.name, startsleep);
        states.Add(sleep.name, sleep);
        states.Add(endsleep.name, endsleep);
        states.Add(forcesleep.name, forcesleep);
    }

    public static void AddFrozenState(Dictionary<string, State> states)
    {
        State frozen = new State("frozen",
                            "busy", "frozen");
        frozen.onenter = new Action<Entity>((Entity inst)=>
                                {
                                    //if (inst.components.ContainsKey(eEntityComponent.locomotor))
                                    //    inst.components[eEntityComponent.locomotor] = frozen;
                                    Debug.Log("frozen.onenter");
                                });
        frozen.onexit = new Action<Entity>((Entity inst)=>
                                {
                                    Debug.Log("frozen.onexit");
                                });
        frozen.events.AddEventListener("onthaw", (Entity inst)=>
                                {
                                    inst.sg.GoToState("thaw");
                                });

        State thaw = new State("thaw",
                               "busy", "thawing");
        thaw.onenter = new Action<Entity>((Entity inst) =>
                        {
                            Debug.Log("thaw.onenter");
                        });
        thaw.onexit = new Action<Entity>((Entity inst) =>
                        {
                            Debug.Log("thaw.onexit");
                        });
        thaw.events.AddEventListener("unfreeze", (Entity inst) =>
                        {
                            Debug.Log("events:unfreeze");
                        });
        states.Add(frozen.name, frozen);
        states.Add(thaw.name, thaw);
    }

    public static void AddCombatStates(Dictionary<string, State> states,
                                Dictionary<string, List<ITimeEvent>> timelines,
                                Dictionary<string, Action<Entity>> anims)
    {
        State hit = new State("hit",
                        "hit", "busy");
        hit.onenter = new Action<Entity>((Entity inst) =>
                            {
                                //if (inst.components.ContainsKey(eEntityComponent.locomotor))
                                //    inst.components[eEntityComponent.locomotor].sto;
                                Debug.Log("hit.onenter");
                            });
        hit.events.AddEventListener("animover", (Entity inst) =>
                            {
                                inst.sg.GoToState("idle");
                            });

        State attack = new State("attack",
                                "attack", "busy");
        attack.onenter = new Action<Entity, Entity>((Entity inst, Entity target) =>
                            {
                                Debug.Log("attack.onenter");
                            });
        attack.events.AddEventListener("animover", (Entity inst) =>
                            {
                                inst.sg.GoToState("idle");
                            });

        State death = new State("death",
                            "busy");
        death.onenter = new Action<Entity>((Entity inst) =>
                            {
                                Debug.Log("death.onenter");
                            });

        if (timelines != null)
        {
            hit.timeline = timelines["hittimeline"];
            attack.timeline = timelines["attacktimeline"];
            death.timeline = timelines["deathtimeline"];
        }

        states.Add(hit.name, hit);
        states.Add(attack.name, attack);
        states.Add(death.name, death);
    }
}


