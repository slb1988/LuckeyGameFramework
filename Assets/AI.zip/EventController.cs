﻿using System;
using System.Collections.Generic;
using UnityEngine;

public class EventHandler
{
    public string eventName;
    Delegate fn;
    EventController processor;

    public void AddEventHandler(string eventName, Action func, EventController processor = null)
    {
        this.eventName = eventName;
        this.fn = func;
        this.processor = processor;
    }

    public void AddEventHandler<T>(string eventName, Action<T> func, EventController processor = null)
    {
        this.eventName = eventName;
        this.fn = func;
        this.processor = processor;
    }

    //public void AddEventHandler<T, U>(string eventName, Action<T, U> func, EventController processor = null)
    //{
    //    this.eventName = eventName;
    //    this.fn = func;
    //    this.processor = processor;
    //}

    //public void AddEventHandler<T, U, V>(string eventName, Action<T, U, V> func, EventController processor = null)                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     ntController processor = null)
    //{
    //    this.eventName = eventName;
    //    this.fn = func;
    //    this.processor = processor;
    //}

    //public void AddEventHandler<T, U, V, W>(string eventName, Action<T, U, V, W> func, EventController processor = null)
    //{
    //    this.eventName = eventName;
    //    this.fn = func;
    //    this.processor = processor;
    //}
}

/// <summary>
/// 事件控制器
/// </summary>
public class EventController
{
    private List<string> m_permanentEvents = new List<string>();
    private Dictionary<string, Delegate> m_listeners = new Dictionary<string, Delegate>();

    public void AddEventListener(string eventType, Action handler)
    {
        OnListenerAdding(eventType, handler);
        m_listeners[eventType] = (Action)Delegate.Combine(m_listeners[eventType], handler);
    }

    public void SetEventListener(string eventType, Action handler)
    {
        if (!m_listeners.ContainsKey(eventType))
            m_listeners.Add(eventType, null);
        m_listeners[eventType] = handler;
    }

    public void AddEventListener<T>(string eventType, Action<T> handler)
    {
        OnListenerAdding(eventType, handler);
        m_listeners[eventType] = (Action<T>)Delegate.Combine(m_listeners[eventType], handler);
    }

    public void SetEventListener<T>(string eventType, Action<T> handler)
    {
        if (!m_listeners.ContainsKey(eventType))
            m_listeners.Add(eventType, null);
        m_listeners[eventType] = handler;
    }

    public void AddEventListener<T, U>(string eventType, Action<T, U> handler)
    {
        OnListenerAdding(eventType, handler);
        m_listeners[eventType] = (Action<T, U>)Delegate.Combine(m_listeners[eventType], handler);
    }

    public void SetEventListener<T, U>(string eventType, Action<T, U> handler)
    {
        if (!m_listeners.ContainsKey(eventType))
            m_listeners.Add(eventType, null);
        m_listeners[eventType] = handler;
    }

    public void AddEventListener<T, U, V>(string eventType, Action<T, U, V> handler)
    {
        OnListenerAdding(eventType, handler);
        m_listeners[eventType] = (Action<T, U, V>)Delegate.Combine(m_listeners[eventType], handler);
    }

    public void SetEventListener<T, U, V>(string eventType, Action<T, U, V> handler)
    {
        if (!m_listeners.ContainsKey(eventType))
            m_listeners.Add(eventType, null);
        m_listeners[eventType] = handler;
    }

    public void AddEventListener<T, U, V, W>(string eventType, Action<T, U, V, W> handler)
    {
        OnListenerAdding(eventType, handler);
        m_listeners[eventType] = (Action<T, U, V, W>)Delegate.Combine(m_listeners[eventType], handler);
    }

    public void SetEventListener<T, U, V, W>(string eventType, Action<T, U, V, W> handler)
    {
        if (!m_listeners.ContainsKey(eventType))
            m_listeners.Add(eventType, null);
        m_listeners[eventType] = handler;
    }

    public void RemoveEventListener(string eventType, Action handler)
    {
        if (OnListenerRemoving(eventType, handler))
        {
            m_listeners[eventType] = (Action)Delegate.Remove(m_listeners[eventType], handler);
            OnListenerRemoved(eventType);
        }
    }

    public void RemoveEventListener<T>(string eventType, Action<T> handler)
    {
        if (OnListenerRemoving(eventType, handler))
        {
            m_listeners[eventType] = (Action<T>)Delegate.Remove(m_listeners[eventType], handler);
            OnListenerRemoved(eventType);
        }
    }

    public void RemoveEventListener<T, U>(string eventType, Action<T, U> handler)
    {
        if (OnListenerRemoving(eventType, handler))
        {
            m_listeners[eventType] = (Action<T, U>)Delegate.Remove(m_listeners[eventType], handler);
            OnListenerRemoved(eventType);
        }
    }

    public void RemoveEventListener<T, U, V>(string eventType, Action<T, U, V> handler)
    {
        if (OnListenerRemoving(eventType, handler))
        {
            m_listeners[eventType] = (Action<T, U, V>)Delegate.Remove(m_listeners[eventType], handler);
            OnListenerRemoved(eventType);
        }
    }

    public void RemoveEventListener<T, U, V, W>(string eventType, Action<T, U, V, W> handler)
    {
        if (OnListenerRemoving(eventType, handler))
        {
            m_listeners[eventType] = (Action<T, U, V, W>)Delegate.Remove(m_listeners[eventType], handler);
            OnListenerRemoved(eventType);
        }
    }

    public void TriggerEvent(string eventType)
    {
        Delegate d = null;
        if (m_listeners.TryGetValue(eventType, out d))
        {
            if (d == null) return;
            var invocationList = d.GetInvocationList();
            for (var i = 0; i < invocationList.Length; i++)
            {
                var action = invocationList[i] as Action;
                if (action == null)
                    throw new EventException(string.Format("Triggering event '{0}' but listeners have a different signature.", eventType));
                try
                {
                    action();
                }
                catch (Exception e)
                {
                    Debug.LogError(e.Message);
                }
            }
        }
    }

    public void TriggerEvent<T>(string eventType, T arg1)
    {
        Delegate d = null;
        if (m_listeners.TryGetValue(eventType, out d))
        {
            if (d == null) return;
            var invocationList = d.GetInvocationList();
            for (var i = 0; i < invocationList.Length; i++)
            {
                var action = invocationList[i] as Action<T>;
                if (action == null)
                    throw new EventException(string.Format("Triggering event '{0}' but listeners have a different signature.", eventType));
                try
                {
                    action(arg1);
                }
                catch (Exception e)
                {
                    Debug.LogError(e.Message);
                }
            }
        }
    }

    public void TriggerEvent<T, U>(string eventType, T arg1, U arg2)
    {
        Delegate d = null;
        if (m_listeners.TryGetValue(eventType, out d))
        {
            if (d == null) return;
            var invocationList = d.GetInvocationList();
            for (var i = 0; i < invocationList.Length; i++)
            {
                var action = invocationList[i] as Action<T, U>;
                if (action == null)
                    throw new EventException(string.Format("Triggering event '{0}' but listeners have a different signature.", eventType));
                try
                {
                    action(arg1, arg2);
                }
                catch (Exception e)
                {
                    Debug.LogError(e.Message);
                }
            }
        }
    }

    public void TriggerEvent<T, U, V>(string eventType, T arg1, U arg2, V arg3)
    {
        Delegate d = null;
        if (m_listeners.TryGetValue(eventType, out d))
        {
            if (d == null) return;
            var invocationList = d.GetInvocationList();
            for (var i = 0; i < invocationList.Length; i++)
            {
                var action = invocationList[i] as Action<T, U, V>;
                if (action == null)
                    throw new EventException(string.Format("Triggering event '{0}' but listeners have a different signature.", eventType));
                try
                {
                    action(arg1, arg2, arg3);
                }
                catch (Exception e)
                {
                    Debug.LogError(e.Message);
                }
            }
        }
    }

    public void TriggerEvent<T, U, V, W>(string eventType, T arg1, U arg2, V arg3, W arg4)
    {
        Delegate d = null;
        if (m_listeners.TryGetValue(eventType, out d))
        {
            if (d == null) return;
            var invocationList = d.GetInvocationList();
            for (var i = 0; i < invocationList.Length; i++)
            {
                var action = invocationList[i] as Action<T, U, V, W>;
                if (action == null)
                    throw new EventException(string.Format("Triggering event '{0}' but listeners have a different signature.", eventType));
                try
                {
                    action(arg1, arg2, arg3, arg4);
                }
                catch (Exception e)
                {
                    Debug.LogError(e.Message);
                }
            }
        }
    }

    public void Cleanup()
    {
        var eventsToRemove = new List<string>();
        foreach (var pair in m_listeners)
        {
            var flag = false;
            foreach (var permanentEvent in m_permanentEvents)
            {
                if (pair.Key == permanentEvent)
                {
                    flag = true;
                    break;
                }
            }
            if (!flag)
                eventsToRemove.Add(pair.Key);
        }

        foreach (var eventToRemove in eventsToRemove)
            m_listeners.Remove(eventToRemove);
    }

    public bool ContainsEvent(string eventType)
    {
        return m_listeners.ContainsKey(eventType);
    }

    public void MarkAsPermanent(string eventType)
    {
        m_permanentEvents.Add(eventType);
    }

    private void OnListenerAdding(string eventType, Delegate listenerBeingAdded)
    {
        if (!m_listeners.ContainsKey(eventType))
            m_listeners.Add(eventType, null);

        var d = m_listeners[eventType];
        if (d != null && d.GetType() != listenerBeingAdded.GetType())
            throw new EventException(string.Format("Attempting to add listener with inconsistent signature for event type {0}. Current listeners have type {1} and listener being added has type {2}", eventType, d.GetType().Name, listenerBeingAdded.GetType().Name));
    }

    private bool OnListenerRemoving(string eventType, Delegate listenerBeingRemoved)
    {
        if (!m_listeners.ContainsKey(eventType))
            return false;

        var d = m_listeners[eventType];
        if ((d != null) && (d.GetType() != listenerBeingRemoved.GetType()))
            throw new EventException(string.Format("Attempting to remove listener with inconsistent signature for event type {0}. Current listeners have type {1} and listener being removed has type {2}", eventType, d.GetType().Name, listenerBeingRemoved.GetType().Name));
        return true;
    }

    private void OnListenerRemoved(string eventType)
    {
        if (m_listeners.ContainsKey(eventType) && (m_listeners[eventType] == null))
            m_listeners.Remove(eventType);
    }
}

