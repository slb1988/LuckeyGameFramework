﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;
using Random = UnityEngine.Random;

//public class State
//{
//    string name;
//    Dictionary<string, bool> tags = new Dictionary<string, bool>();
//    Delegate onenter;
//    List<ITimeEvent> timeline = new List<ITimeEvent>();
//    EventController events;
//}


public class ActionHandler
{
    StateAction action;
    Func<string> deststate;           //返回string状态的函数
    Func<bool> condition;
     
    public ActionHandler(StateAction action, string state, Func<bool> condition = null)
    {
        this.action = action;
        this.deststate = new Func<string>(()=>{return state;});
        this.condition = condition;
    }

    public ActionHandler(StateAction action, Func<string> state, Func<bool> condition)
    {
        this.action = action;
        this.deststate = state;
        this.condition = condition;
    }
}

public interface ITimeEvent
{
    //float time;
    //Delegate fn;
    float getTime();
    void invoke(params object[] objs);
}

public class TimeEvent<T, U, V, W> : ITimeEvent
{
    float time;
    Delegate fn;

    public float getTime()
    {
        return time;
    }

    public void invoke(params object[] objs)
    {
        fn.DynamicInvoke(objs);
    }

    public TimeEvent(float time, Action fn)
    {
        this.time = time;
        this.fn = fn;
    }

    public TimeEvent(float time, Action<T> fn)
    {
        this.time = time;
        this.fn = fn;
    }

    public TimeEvent(float time, Action<T, U> fn)
    {
        this.time = time;
        this.fn = fn;
    }

    public TimeEvent(float time, Action<T, U, V> fn)
    {
        this.time = time;
        this.fn = fn;
    }

    public TimeEvent(float time, Action<T, U, V, W> fn)
    {
        this.time = time;
        this.fn = fn;
    }
}

public class State
{
    public string name;
    public Dictionary<string, bool> tags;
    public Delegate onenter;
    public Delegate onexit;
    public Delegate onupdate;
    public Delegate ontimeout;

    private State()
    {
        tags = new Dictionary<string, bool>();
    }

    public State(string statename, params string[] pTags)
    {
        this.name = statename;
        tags = new Dictionary<string, bool>();
        foreach (var tag in pTags)
        {
            tags.Add(tag, true);
        }
    }

    public List<ITimeEvent> timeline = new List<ITimeEvent>();
    public EventController events = new EventController();

    public void HandleEvent(StateGraph sg, string eventName)
    {
        events.TriggerEvent(eventName);


    }
}

public class StateGraph
{
    public string name;
    public string defaultstate;
    public List<ActionHandler> actionhandlers;

    public EventController events;
    public Dictionary<string, State> states;
    
    //public StateGraph(string name, Dictionary<string, State> states, List<string> events, string defaultstate, string actionhandlers)
    //{
    //}
}

public class SGflog : StateGraph
{
    public SGflog()
    {
        name = "sgflog";
        defaultstate = "Idle";
        actionhandlers = new List<ActionHandler>();
        actionhandlers.Add(new ActionHandler(ACTIONS.GOHOME, "action"));
        actionhandlers.Add(new ActionHandler(ACTIONS.EAT, "eat_loop"));
        actionhandlers.Add(new ActionHandler(ACTIONS.PICKUP, "eat_enter"));

        events = new EventController();
        CommonHandlers.OnLocomote(events, false, true);
        CommonHandlers.OnFreeze(events);
        CommonHandlers.OnAttack(events);
        CommonHandlers.OnAttacked(events);
        CommonHandlers.OnDeath(events);
        CommonHandlers.OnSleep(events);

        states = new Dictionary<string, State>();
        State idlestate = new State("idle",
                                "idle", "canrotate");
        idlestate.tags["canrotate"] = false;
        //idlestate.name = "idle";
        //idlestate.tags.Add("idle", true);
        //idlestate.tags.Add("canrotate", false);
        idlestate.onenter = new Action<Entity, string>((Entity inst, string playanim) =>
            {
                Debug.Log("frog onenter");
            });
        idlestate.timeline.Add(new TimeEvent<Entity, int,int,int>(0.3f,
                                (Entity inst) =>
                                {
                                    Debug.Log("wingdown " + Time.time);
                                }));
        idlestate.timeline.Add(new TimeEvent<Entity, int, int, int>(0.5f,
                                (Entity inst) =>
                                {
                                    Debug.Log("wingdown" + Time.time);
                                }));

        idlestate.events.AddEventListener("animover",
                                    (Entity inst) =>
                                    {
                                        Debug.Log("idle " + Time.time);
                                    });
        states.Add(idlestate.name, idlestate);

        State deathstate = new State("death",
                                    "busy");
        deathstate.onenter = new Action<Entity>((Entity inst) =>
                                {
                                    Debug.Log("death onenter" + Time.time);
                                });
        states.Add(deathstate.name, deathstate);

        List<ITimeEvent> tempTE = new List<ITimeEvent>();
        tempTE.Add(new TimeEvent<Entity, int,int,int>(0, (Entity inst) =>
                        {
                        }));
        Dictionary<string, List<ITimeEvent>> tempDic = new Dictionary<string, List<ITimeEvent>>();
        tempDic.Add("waketimeline", tempTE);
        CommonStates.AddSleepStates(states, tempDic, null);

        CommonStates.AddFrozenState(states);
    }


}

        //self.sg = StateGraphInstance(sg, self)
        //SGManager:AddInstance(self.sg)
        //self.sg:GoToState(self.sg.sg.defaultstate)

public class StateGraphInstance
{
    Dictionary<string, bool> tags = new Dictionary<string, bool>();
    StateGraph sg;
    Entity inst;
    State currentstate;
    float timeinstate;              //记录时间
    float lastupdatetime;           //上次更新时间
    float statestarttime;           //记录当前状态开始时间

    

    public StateGraphInstance(StateGraph sg, Entity inst)
    {
        this.sg = sg;
        this.inst = inst;
        this.statestarttime = 0;
    }

    public float GetTimeInState()
    {
        return Time.realtimeSinceStartup - statestarttime;
    }

    public void PlayRandomAnim(Animation anims, bool loop)
    {
        int idx = (int)Math.Floor(Random.Range(0f, 1f) * anims.GetClipCount());
    }

    public void PushEvent(string eventName, params object[] objs)
    {

    }

    public void GoToState(string statename, params object[] objs)
    {
        State state;
        if (sg.states.TryGetValue(statename, out state))
        {

        }
        else
            Debug.Log(string.Format("{0} Tried to go to invalid state {1}", inst, statename));
    }

    public override string ToString() { return "StateGraphInstance"; }
    
}

public struct FuncsDic
{
    string funcName;
    Action<Entity> func;
}

public class StateGraphWrangler
{
    public List<Entity> instances;
    public List<Entity> updaters;
    public List<Entity> tickwaiters;
    public List<Entity> hibernaters;
    public List<Entity> haveEvents;


    public StateGraphWrangler()
    {
        instances = new List<Entity>();
    }


}